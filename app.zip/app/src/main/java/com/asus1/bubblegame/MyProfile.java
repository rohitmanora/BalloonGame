package com.asus1.bubblegame;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.ads.InterstitialAd;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.jar.Attributes;

/**
 * Created by Asus 1 on 11/28/2017.
 */

public class MyProfile extends AppCompatActivity {


    EditText name, username, mobile;
    String name1, username1, mobile1;
    ImageView logo;
    Button submit, skip;
    String id;
    int count = 0, checkSkip = 0;
    int bclink=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_profile);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        System.out.println("device id"+Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID).toString());
        name = (EditText) findViewById(R.id.fullname);
        logo = (ImageView) findViewById(R.id.imglogo);
        username = (EditText) findViewById(R.id.usernmae);
        mobile = (EditText) findViewById(R.id.mobile);
        submit = (Button) findViewById(R.id.submit);

        InterstitialAd ad = AdManger.getAd();
        if (ad != null) {
            ad.show();
        }


        SharedPreferences setting = getSharedPreferences("GAME_SCORE", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = setting.edit();


        final String Did = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID).toString();
        registerData(Did);

//        int count1 = setting.getInt("COUNT", 0);
//        int checkSkip1=setting.getInt("CHECKSKIP",0);
//        if(checkSkip1>0){
//            // playButton.setVisibility(View.GONE);
//            skip.setVisibility(View.GONE);
//            logo.setVisibility(View.GONE);
//        }
//        System.out.print("value of count"+count1);
//        if(count1>0){
//            Intent i=new Intent(MyProfile.this,GameActivity.class);
//            startActivity(i);
//        }

//        skip.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                count++;
//                checkSkip++;
//                SharedPreferences setting = getSharedPreferences("GAME_SCORE", Context.MODE_PRIVATE);
//                SharedPreferences.Editor editor = setting.edit();
//                editor.putInt("COUNT", count);
//                editor.putInt("CHECKSKIP",checkSkip);
//                editor.commit();
//
//                Intent i1=new Intent(MyProfile.this,GameActivity.class);
//                startActivity(i1);
//            }
//        });
//        submit.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
////                String Did=Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID).toString();
//             //   System.out.println("id.........."+Did);
//                String Name=name.getText().toString().trim();
//                System.out.println("name........."+Name);
//                String Username=username.getText().toString().trim();
//                String Mobile=mobile.getText().toString().trim();
//
//
//
//                SharedPreferences setting = getSharedPreferences("GAME_SCORE", Context.MODE_PRIVATE);
////                int oldscore = setting.getInt("OLD_SCORE", 0);
//
//                count++;
//                SharedPreferences.Editor editor = setting.edit();
//                editor.putString("NAME", Name);
//                editor.putString("USERNAME",Username);
//                editor.putString("MOBILE",Mobile);
//                editor.putInt("COUNT", count);
//                editor.commit();
//
//                Intent i=new Intent(MyProfile.this,GameActivity.class);
//                startActivity(i);
//
//            }

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Did = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID).toString();

                String Name= name.getText().toString().trim();
                String NameNew=Name.replaceAll("\\s","%20");
                String UsernameNew = username.getText().toString().trim().replaceAll("\\s","%20");
                String MobileNew = mobile.getText().toString().trim().replaceAll("\\s","%20");
                SharedPreferences setting = getSharedPreferences("GAME_SCORE", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = setting.edit();
                editor.putString("NAME", Name);
                editor.putString("USERNAME",UsernameNew);
                editor.putString("MOBILE",MobileNew);
                editor.commit();

                updateProfile(Did, NameNew, UsernameNew, MobileNew);
                Intent i = new Intent(MyProfile.this, GameActivity.class);
                startActivity(i);
               // finish();
            }
        });
    }

    public void updateProfile(String Deviceid, String Name, String Username, String Mobile) {
        class InsertDataProfile extends AsyncTask<String, Void, String> {

            ProgressDialog pd = new ProgressDialog(MyProfile.this);
            HttpURLConnection conn;
            URL url;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd.setMessage("data inserting...");
                pd.setCancelable(false);
                pd.show();
            }


            @Override
            protected String doInBackground(String... params) {
                String params_did = params[0];
                String params_name = params[1];
                String params_username = params[2];
                String params_mobile = params[3];


                try {
                    url = new URL("http://bubble.arpitharsola.com/register.php?deviceid=" + params_did + "&name=" + params_name + "&username=" + params_username + "&mobile=" +
                            params_mobile);
                    //          http://192.168.43.38/Food/updateMenu.php?day=ggd%20&earlymorning=pp%20&breakFast=qq&lunch=ffff&snacks=ff&dinner=lopd

                    conn = (HttpURLConnection) url.openConnection();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    String result = bufferedReader.readLine().toString();
                    return result;
                } catch (Exception e) {
                    e.printStackTrace();
                    return e.toString();
                }

            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                pd.dismiss();

                System.out.print("value of s after sbm button........." + s);
                if (s.trim().equals("Register")) {
                    Toast.makeText(MyProfile.this, "Update... succesfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MyProfile.this, " not updated", Toast.LENGTH_SHORT).show();
                }
            }
        }
        InsertDataProfile insertDataProfile = new InsertDataProfile();
        insertDataProfile.execute(Deviceid, Name, Username, Mobile);

    }


    private void registerData(String Deviceid) {

        class InsertData extends AsyncTask<String, Void, String> {

            ProgressDialog pd = new ProgressDialog(MyProfile.this);
            HttpURLConnection conn;
            URL url;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd.setMessage("data inserting...");
                pd.setCancelable(false);
                pd.show();
            }


            @Override
            protected String doInBackground(String... params) {
                String params_did = params[0];

                try {
                    url = new URL("http://bubble.arpitharsola.com/fetchuserinfo.php?deviceid=" + params_did);
                    conn = (HttpURLConnection) url.openConnection();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    String result = bufferedReader.readLine().toString();
                    return result;
                } catch (Exception e) {
                    e.printStackTrace();
                    return e.toString();
                }

            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                pd.dismiss();
                System.out.println("value of s.........." + s);

                try {
                    JSONObject jsonObject = new JSONObject(s);
                    JSONArray jsonArray = jsonObject.getJSONArray("result");

                    //  for(int i=0;i<jsonArray.length();i++){
                    JSONObject jo = jsonArray.getJSONObject(0);

                    name1 = jo.getString("name");
                    username1 = jo.getString("username");
                    mobile1 = jo.getString("mobile");
                    name.setText(name1);
                    username.setText(username1);
                    System.out.println("username" + username1);
                    mobile.setText(mobile1);
                    // }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }
        InsertData insertData = new InsertData();
        insertData.execute(Deviceid);

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode== KeyEvent.KEYCODE_BACK)
            bclink++;
        if(bclink>1){
            Intent i=new Intent(MyProfile.this,GameActivity.class);
            startActivity(i);
        }

        return false;
        // Disable back button..............
    }
}

