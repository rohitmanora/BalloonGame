package com.asus1.bubblegame;

/**
 * Created by Asus 1 on 11/9/2017.
 */

public class Constants {

    public static String FIRST_COLUMN="First";
    public static String SECOND_COLUMN="Second";
    public static String THIRD_COLUMN="Third";

}
