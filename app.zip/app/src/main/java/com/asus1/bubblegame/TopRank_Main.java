package com.asus1.bubblegame;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.RequiresApi;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.InterstitialAd;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

import static com.asus1.bubblegame.Constants.FIRST_COLUMN;
import static com.asus1.bubblegame.Constants.SECOND_COLUMN;
import static com.asus1.bubblegame.Constants.THIRD_COLUMN;

public class TopRank_Main extends Activity {

    private ArrayList<HashMap<String, String>> list;
    ListViewAdapterNew adapter;


    TextView myscore;
    String co="0";
    int count=0;
   int rank=0;
    int scoremy=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.toprank_activitymain);
        myscore=(TextView)findViewById(R.id.mysco);
        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        InterstitialAd ad = AdManger.getAd();
        if (ad != null) {
            ad.show();
        }

        SharedPreferences setting = getSharedPreferences("GAME_SCORE", Context.MODE_PRIVATE);
         scoremy = setting.getInt("OLD_SCORE", 0);

//        arrayList = new ArrayList<>();
//        recyclerView = new RecyclerView(TopRank_Main.this);

//        myscore.setText("My Score "+scoremy+"  Rank "+rank);

        fetchAllScore();
       // ListView listView=(ListView)findViewById(R.id.listvie);
        ListView listView=(ListView)findViewById(R.id.listvie);
        list=new ArrayList<HashMap<String,String>>();
//         fetchAllScore();

    }

    private void fetchAllScore() {
    //    Toast.makeText(TopRank_Main.this,"fetch all score",Toast.LENGTH_LONG).show();
        class Fetch extends AsyncTask<String,Void,String> {
            ProgressDialog pd=new ProgressDialog(TopRank_Main.this);
            URL url;
            HttpURLConnection conn;



            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd.setMessage("fetching top score...");
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            protected String doInBackground(String... params) {
                try {
                        url = new URL("http://bubble.arpitharsola.com/fetchscore1.php?");

                  //  url=new URL("http://192.168.43.38/Bubble/fetchscore.php?");
                    conn = (HttpURLConnection) url.openConnection();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    String result = bufferedReader.readLine().toString();
                    return result;
                } catch (Exception e) {
                    e.printStackTrace();
                    return e.toString();
                }//
            }



            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                pd.dismiss();
//                int count_final=0;

//                ListView listView=(ListView)findViewById(R.id.listvie);

                list=new ArrayList<HashMap<String,String>>();


                try {
                    JSONObject jsonObject=new JSONObject(s);
                    JSONArray jsonArray=jsonObject.getJSONArray("result");
                 //   Toast.makeText(TopRank_Main.this, jsonArray.toString(), Toast.LENGTH_SHORT).show();
                    for(int i=0;i<10;i++) {
                        int co = 1+i;
                        JSONObject jo = jsonArray.getJSONObject(i);
                        HashMap<String, String> temp = new HashMap<String, String>();
                        temp.put(FIRST_COLUMN, String.valueOf(co));
                        temp.put(SECOND_COLUMN, jo.getString("score"));
                        String name = jo.getString("name");
                        String deviceid = jo.getString("deviceid");

                        String deviceid1 = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID).toString();
                        if (deviceid1.trim().equals(deviceid)) {
                            count = 1;
                            //adapter=new ListViewAdapterNew(TopRank_Main.this,list);
                            // adapter.txtFirst.setBackgroundColor(0xfff00000);
                            temp.put(THIRD_COLUMN, "My score");
                        } else {
                            if (!name.isEmpty()) {
                                temp.put(THIRD_COLUMN, jo.getString("name"));
                            } else if (name.isEmpty()) {
                                //temp.put(THIRD_COLUMN, jo.getString("deviceid"));
                                temp.put(THIRD_COLUMN, "guest player");
                            }
                        }
                        list.add(temp);

                    }
                    String deviceid2 = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID).toString();
                    for(int i=0;i<jsonArray.length();i++) {
                        JSONObject jo = jsonArray.getJSONObject(i);
                        String deviceid = jo.getString("deviceid");
                        rank++;
                         if(deviceid.trim().equals(deviceid2)){
                             break;
                         }

                    }
                    if(count==0) {
                       if(scoremy==0){
                           myscore.setText("My Score "+scoremy);
                       }else{
                           myscore.setText("My Score "+scoremy+"  Rank "+rank);
                       }

                    }
                    else if(count==1){
                        if(scoremy==0){
                            myscore.setText("My Score "+scoremy);
                        }else{
                            myscore.setText("My Score "+scoremy+"  Rank "+rank);
                        }
                    }



                } catch (JSONException e) {
                    e.printStackTrace();
                    count=2;
                    System.out.println("exception is there.........");
                }
                finally
                {

                }
              try{
                  adapter=new ListViewAdapterNew(TopRank_Main.this, list);
                  final ListView listView=(ListView)findViewById(R.id.listvie);
                  listView.setAdapter(adapter);

                  listView.post(new Runnable() {
                      @Override
                      public void run() {
                          listView.smoothScrollToPosition(0);
                         // Toast.makeText(getApplication(),scroll list,T)
                      }
                  });
              }catch (Exception e){
                  System.out.println("exception in adapter list........................");
              }
            }
        }
       Fetch fetch=new Fetch();
        fetch.execute();

    }
}
