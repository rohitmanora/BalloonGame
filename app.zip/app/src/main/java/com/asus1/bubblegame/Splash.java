package com.asus1.bubblegame;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Window;
import android.view.WindowManager;

public class Splash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);
        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


        //For hiding android actionbar
        ActionBar myActionBar = getSupportActionBar();

        myActionBar.hide();

        Thread timer = new Thread() {
            public void run() {
                try {
                    sleep(2280);
                } catch (InterruptedException e) {
                    e.printStackTrace();

                } finally {
                    Intent openStartingPoint = new Intent(Splash.this,MainActivity.class);
                    startActivity(openStartingPoint);


                }
            }
        };
        timer.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
}


