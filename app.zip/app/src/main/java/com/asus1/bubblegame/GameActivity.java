package com.asus1.bubblegame;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.AssetFileDescriptor;
import android.graphics.Point;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.Display;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class GameActivity extends AppCompatActivity {

    Random rand = new Random();
    ImageButton paly_pausee;
    int check=1;
    int on_off=0;
    int temp=0;
    int thread=0;
   static int checkpause=1;
    final MediaPlayer mp = new MediaPlayer();
    final MediaPlayer mp1 = new MediaPlayer();
    int bclick=0;
    private ImageView chara, white, blue,black,yellow;
    TextView scoretv;
    Button press;
    //Size
    private int frameHeight; //we tke FrameLayout Heightby .getHeight method
    private int boxSize;  //nd boxSize by ->boxSize = box.getHeight();
    private int screenWidth;
    private int screenHeight;

    //Status Check
    private boolean action_flag = false;
    private boolean start_flag = false;

    //Speed
    private int boxSpeed=0;
    private int whiteSpeed=0;
    private int blueSpeed=0;
    private int blackSpeed=0;
    private int yellowspeed=0;

    //Position of Box
    int boxY=0, boxX;
    int whiteX=0, whiteY=0, blueX=0, blueY=0,blackY=0,yellowX=0,yellowY=0;
    double blackX=0;
    int score = 0;

    private Handler handler = new Handler();
    private Timer timer = new Timer();


    public static final String MY_PREFS_NAME = "MyPrefsFile";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        AdManger adManager = new AdManger(this,"ca-app-pub-4679276108759944/1950678095");
        adManager.createAd();

       paly_pausee=(ImageButton)findViewById(R.id.play_pause);
       paly_pausee.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

               play_pause_method();
           }

       });




        press = (Button) findViewById(R.id.press1);
        chara = (ImageView) findViewById(R.id.character);
        white = (ImageView) findViewById(R.id.white);
        blue = (ImageView) findViewById(R.id.blue);
        black=(ImageView)findViewById(R.id.black);
        yellow=(ImageView)findViewById(R.id.yellow);
        scoretv = (TextView) findViewById(R.id.score);
        //Get screen Size
        WindowManager wm = getWindowManager();
        Display display = wm.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);

        screenWidth = size.x;
        screenHeight = size.y;

        //speed of our charac
        boxSpeed = Math.round(screenHeight / 60F);
        whiteSpeed = Math.round(screenWidth / 60F);
        yellowspeed = Math.round(screenWidth / 45F); //medium
        blueSpeed = Math.round(screenWidth / 35F);//fast
        blackSpeed=Math.round(screenWidth/35F);
        //set bubble out of the screen
        white.setX(0b11111111111111111111111110110000); //binary of -80
        white.setY(0b11111111111111111111111110110000);
        blue.setX(0b11111111111111111111111110110000);
        blue.setY(0b11111111111111111111111110110000);
        black.setX(0b11111111111111111111111110110000);
        black.setY(0b11111111111111111111111110110000);
        yellow.setX(0b11111111111111111111111110110000);
        yellow.setY(0b11111111111111111111111110110000);


        press.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                if (start_flag == false) {
                    start_flag = true;

                    FrameLayout frame = (FrameLayout) findViewById(R.id.frame);
                    frameHeight = frame.getHeight();

                    boxY = (int) chara.getY();


                    // the box is a sqare(height nd width are same)
                    boxSize = chara.getHeight();



                        timer.schedule(new TimerTask() {
                            @Override
                            public void run() {
                                handler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (thread == 0) {
                                            System.out.println("thread value/////"+thread);
                                            changePos();
                                        }
                                    }
                                });
                            }
                        }, 0, 20);
                    }

                //whn user touch on the screen
                else {
                    if (event.getAction() == MotionEvent.ACTION_DOWN) {
                        action_flag = true;
                    } else if (event.getAction() == MotionEvent.ACTION_UP) {
                        action_flag = false;
                    }
                }


                return true;
            }
        });

    }


    private void changePos() {
     // System.out.println("game activity chengepos method value of check pause"+checkpause);
        if (checkpause ==1) {
            checkCollisiion();
//            every time when chngePos mthd call whiteX decreased by -12(means it moved toward leftSide)
            whiteX -= whiteSpeed;
            blueX -= blueSpeed;
            blackX -= blackSpeed;
            yellowX -= yellowspeed;
            // whn orangeX value <0 thn its goes out of screen
            if (whiteX < 0) {
                if (score < 250) {
                    whiteX = screenWidth + 60;
                } else if (score < 450) {
                    whiteX = screenWidth + 40;
                } else if (score < 600) {
                    whiteX = screenWidth + 30;
                } else if (score < 800) {
                    whiteX = screenWidth + 20;
                } else if (score < 1000) {
                    whiteX = screenWidth + 10;
                }
                else{
                    whiteX=screenWidth+7;
                }
                // whiteX = screenWidth + 20; //means it goes out of screen
                //random position of orangeY GENERATE b/w frameHeight-orange
                // whiteY =(int)Math.floor(Math.random()*(frameHeight-white.getHeight())); or
//            Random rand = new Random();
                whiteY = rand.nextInt(frameHeight - white.getHeight());
            }

            //white X and Y value set
            white.setX(whiteX);
            white.setY(whiteY);

            if (blueX < 0) {
                if (score < 250) {
                    blueX = screenWidth + 5000;
                } else if (score < 450) {
                    blueX = screenWidth + 4200;
                } else if (score < 600) {
                    blueX = screenWidth + 3500;
                } else if (score < 800) {
                    blueX = screenWidth + 2900;
                } else if (score < 1000) {
                    blueX = screenWidth + 2200;
                }
                else{
                    blueX=screenWidth+1900;
                }
                //   blueX = screenWidth + 5000;
                Random rand = new Random();
                blueY = rand.nextInt(frameHeight - blue.getHeight());
            }
            blue.setX(blueX);
            blue.setY(blueY);

            if (yellowX < 0) {
                if (score < 250) {
                    yellowX = screenWidth + 2300;
                } else if (score < 450) {
                    yellowX = screenWidth + 2000;
                } else if (score < 600) {
                    yellowX = screenWidth + 1800;
                } else if (score < 800) {
                    yellowX = screenWidth + 1700;
                } else if (score < 1000) {
                    yellowX = screenWidth + 1300;
                }
                else{
                    yellowX=screenWidth+1200;
                }
                //    yellowX = screenWidth + 2000;
                Random rand = new Random();
                yellowY = rand.nextInt(frameHeight - yellow.getHeight());
            }
            yellow.setX(yellowX);
            yellow.setY(yellowY);


            //for black
            if (blackX < 0) {
                if (score < 250) {
                    blackX = screenWidth + 2500;
                } else if (score < 450) {
                    blackX = screenWidth + 2100;
                } else if (score < 600) {
                    blackX = screenWidth + 1900;
                } else if (score < 800) {
                    blackX = screenWidth + 1600;
                } else if (score < 1000) {
                    blackX = screenWidth + 1300;
                }else{
                    blackX=screenWidth+1100;
                }

                Random rand = new Random();
                blackY = rand.nextInt(frameHeight - black.getHeight());
            }
            black.setX((float) blackX);
            black.setY(blackY);
            if (action_flag == true) {
                //touch on screen
                boxY -= boxSpeed;
            } else {
                boxY += boxSpeed;
            }
            if (boxY < 0) {
                boxY = 0;
            }
            if (boxY > frameHeight - boxSize) {
                boxY = frameHeight - boxSize;
            }
            chara.setY(boxY);

            scoretv.setText("Score :" + score);
        }
    }

    private void checkCollisiion() {
        int whiteCenterX = whiteX + white.getWidth() / 2;
        int whiteCenterY = whiteY + white.getHeight() / 2;
        int blueCenterX = blueX + blue.getWidth() / 2;
        int blueCenterY = blueY + blue.getHeight() / 2;
        int yellowCenterX = yellowX + blue.getWidth() / 2;
        int yellowCenterY = yellowY + blue.getHeight() / 2;
        int blackCenterX = (int) (blackX + black.getWidth() / 2);
        int blackCenterY = blackY + black.getHeight() / 2;


        if (0 <= whiteCenterX && whiteCenterX <= boxSize &&
                boxY <= whiteCenterY && whiteCenterY <= boxY + boxSize) {
            hitbeepsound();
            whiteX = -20;
            score += 10;
        }
        if (0 <= blueCenterX && blueCenterX <= boxSize &&
                boxY <= blueCenterY && blueCenterY <= boxY + boxSize) {
            hitbeepsound();
            blueX = -20;
            score += 50;
        }
        if (0 <= yellowCenterX && yellowCenterX <= boxSize &&
                boxY <= yellowCenterY && yellowCenterY <= boxY + boxSize) {
            hitbeepsound();
            yellowX = -20;
            score += 30;
        }


//        if (0 <= blackCenterX && blackCenterX <= boxSize &&
//                boxY <= blackCenterY && blackCenterY <= boxY + boxSize) {
        if (0 <= blackCenterX && blackCenterX <= boxSize &&
                boxY <= blackCenterY && blackCenterY <= boxY + boxSize) {
            blackX = -.1;
            gameoversound();
            timer.cancel();
            timer = null;

            Intent intent = new Intent(getApplicationContext(), MyScore.class);
            intent.putExtra("CURSCORE", score);
            startActivity(intent);
        }
    }


    private void gameoversound() {
        try {
        if (mp1.isPlaying()) {
            mp1.stop();
        }


            mp1.reset();
            AssetFileDescriptor afd;
            afd = getAssets().openFd("oversound.mp3");
            mp1.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            mp1.prepare();
            mp1.start();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void hitbeepsound() {
        try {
        if (mp.isPlaying()) {
            mp.stop();
        }
         mp.reset();
            AssetFileDescriptor afd;
            afd = getAssets().openFd("hitsound.mp3");
            mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            mp.prepare();
            mp.start();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }



    private void play_pause_method() {
        if (check == 1 && temp==0) {
            paly_pausee.setBackgroundDrawable(getResources().getDrawable(R.drawable.play));
            checkpause=0;
            temp=1;
        }
        else if(check==1 && temp==1){
            paly_pausee.setBackgroundDrawable(getResources().getDrawable(R.drawable.pause));
            checkpause=1;
            temp=0;
        }
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        MediaPlayer mp1=MediaPlayer.create(this,R.raw.oversound);
        MediaPlayer mp=MediaPlayer.create(this,R.raw.hitsound);
        mp.stop();
        mp.release();
        mp1.stop();
        mp1.release();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);//Menu Resource, Menu
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.item1:
//                SharedPreferences setting = getSharedPreferences("GAME_SCORE", Context.MODE_PRIVATE);
//                SharedPreferences.Editor editor = setting.edit();
//                editor.putInt("COUNT", 0); //we add 0 value of count
//                editor.commit();
                thread=1;
                 Intent intent=new Intent(GameActivity.this,MyProfile.class);
//                intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
//                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();

                return true;
            case R.id.item2: //toprank
//                Intent intent=new Intent(getApplicationContext(),TopRankNew.class);
                Intent intent1=new Intent(getApplicationContext(),TopRank_Main.class);
                play_pause_method();
                startActivity(intent1);

                return true;






            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override

    public void onResume() {
        System.out.println("on resume call...1st");

            System.out.println("on resume call...in side ");
            super.onResume();

        //super.onResume();
       // if (VERBOSE) Log.v(TAG, "+ ON RESUME +");
    }

    @Override
    public void onPause() {
     //   Toast.makeText(getApplicationContext(),"pause call",Toast.LENGTH_SHORT).show();
        System.out.println("on pause call...");

            super.onPause();
            if(checkpause==1) {
               // mp.release();
            }

    }
      //  mp.release();
     //   mp1.release();
      //  if (VERBOSE) Log.v(TAG, "- ON PAUSE -");


    @Override
    protected void onStop() {
        //Toast.makeText(getApplicationContext(),"stop call",Toast.LENGTH_SHORT).show();
        super.onStop();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode== KeyEvent.KEYCODE_BACK)
            bclick++;
        if(bclick>1){
            Toast.makeText(getApplicationContext(), "back press"+bclick,
                    Toast.LENGTH_LONG).show();
            finishAffinity();
            System.exit(0);
        }

        return false;
        // Disable back button..............
    }

}
