package com.asus1.bubblegame;

import android.app.Activity;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

/**
 * Created by Asus 1 on 11/28/2017.
 */

public class AdManger {
    // Static fields are shared between all instances.
    private static InterstitialAd interstitialAd;

    private static boolean isInterAdsShowed = false;
    private Activity activity;
    private String AD_UNIT_ID;

    AdManger(Activity activity, String AD_UNIT_ID) {

        this.activity = activity;
        this.AD_UNIT_ID = AD_UNIT_ID;
        createAd();
    }

    void createAd() {
        // Create an ad.
        interstitialAd = new InterstitialAd(activity);
        interstitialAd.setAdUnitId(AD_UNIT_ID);
        System.out.println("ad is creAted..........");
        AdRequest adRequest = new AdRequest.Builder()
                //.addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                //.addTestDevice(TEST_DEVICE_ID)
                .build();

        // Load the interstitial ad.
        interstitialAd.loadAd(adRequest);
        System.out.println("ad is loaded");
    }

    static InterstitialAd getAd() {
        if (interstitialAd != null && interstitialAd.isLoaded()) {
            isInterAdsShowed = true;
            return interstitialAd;
        } else return null;
    }
}
