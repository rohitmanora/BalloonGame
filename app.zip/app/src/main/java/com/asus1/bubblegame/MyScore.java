package com.asus1.bubblegame;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

//import com.google.android.gms.appindexing.Action;
//import com.google.android.gms.appindexing.AppIndex;
//import com.google.android.gms.appindexing.Thing;
//import com.google.android.gms.common.api.GoogleApiClient;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.HashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import static com.asus1.bubblegame.Constants.FIRST_COLUMN;
import static com.asus1.bubblegame.Constants.SECOND_COLUMN;
import static com.asus1.bubblegame.Constants.THIRD_COLUMN;


public class MyScore extends AppCompatActivity {

    int count;
    String fetchscorestr;
    int fetchscoreint;
    private InterstitialAd  mInterstitialAd;
    TextView totalscore, curentscore;
    Button submitscore;

    int totalScore1;

    int score=0, totalScore=0,bclick=0;
    String name;
    Button play;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        requestWindowFeature(Window.FEATURE_NO_TITLE);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
//                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.myscore_activity);
        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
       //For hiding android actionbar
        ActionBar myActionBar = getSupportActionBar();
        myActionBar.hide();

        InterstitialAd ad = AdManger.getAd();
        if (ad != null) {
            ad.show();
        }



        submitscore = (Button) findViewById(R.id.submit);
        totalscore = (TextView) findViewById(R.id.totalsco);
        curentscore = (TextView) findViewById(R.id.currentsco);

         play=(Button)findViewById(R.id.playagai);
         play.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 Intent i=new Intent(MyScore.this,GameActivity.class);
                 startActivity(i);
             }
         });
        try {
            score = getIntent().getIntExtra("CURSCORE", 0); //0 is default value
            SharedPreferences setting = getSharedPreferences("GAME_SCORE", Context.MODE_PRIVATE);

            int oldscore = setting.getInt("OLD_SCORE", 0);
            totalScore = score + oldscore;

            SharedPreferences.Editor editor = setting.edit();
            editor.putInt("OLD_SCORE", totalScore);
            editor.commit();

             name = setting.getString("NAME",null);
             System.out.println("name myscore activity...................."+name);

        } catch (Exception e) {

        } finally {

            curentscore.setText(Integer.toString(score));
            totalscore.setText(Integer.toString(totalScore));
        }

        //method call... data send on server
        fetchfromserver();
        sendDataOnServer();

    }

    private void showInterstitial() {
        if(mInterstitialAd.isLoaded()){
            mInterstitialAd.show();
        }
    }


    public void fetchfromserver(){
        class FetchData extends AsyncTask<String,Void,String>{

            ProgressDialog pd=new ProgressDialog(MyScore.this);
            HttpURLConnection conn;
            URL url;
            @Override
            protected void onPreExecute() {

                super.onPreExecute();
            }


            @Override
            protected String doInBackground(String... params) {
                String params_deviceid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

                 try {
                    url = new URL("http://bubble.arpitharsola.com/fetchsinglescore.php?deviceid=" + params_deviceid);
                    Log.v("old data..",String.valueOf(url));

                    conn = (HttpURLConnection) url.openConnection();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    String result = bufferedReader.readLine().toString();
                    return result;
                } catch (Exception e) {
                    e.printStackTrace();
                    return e.toString();
                }

            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                pd.dismiss();
                try {
                    JSONObject jsonObject=new JSONObject(s);
                    JSONArray jsonArray=jsonObject.getJSONArray("result");
                    //   Toast.makeText(TopRank_Main.this, jsonArray.toString(), Toast.LENGTH_SHORT).show();
                    for(int i=0;i<jsonArray.length();i++) {
                        JSONObject jo = jsonArray.getJSONObject(i);
                        fetchscorestr = jo.getString("score");
                        fetchscoreint=Integer.parseInt(fetchscorestr);
                        System.out.print("POST.......fetch server score..........."+fetchscoreint);

                    }
                 } catch (JSONException e) {
                    e.printStackTrace();

                }




                try {
                    SharedPreferences setting = getSharedPreferences("GAME_SCORE", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = setting.edit();
                    int count1 = setting.getInt("COUNT1", 0);
                    if (count1 == 0) {
                        int newgamescore = getIntent().getIntExtra("CURSCORE", 0); //0 is default value
                        score = newgamescore;
                        System.out.println("if fetch score..............." + score);
                        count1=2;
                        totalScore1 = fetchscoreint+newgamescore ;
                        editor.putInt("COUNT1", count1);
                        editor.putInt("OLD_SCORE", totalScore1);
                        editor.commit();
                        curentscore.setText(Integer.toString(score));
                        totalscore.setText(Integer.toString(totalScore1));
                    } else {

                        score = getIntent().getIntExtra("CURSCORE", 0); //0 is default value
                        System.out.println("fetch else in..............." + score);
                        int oldscore = setting.getInt("OLD_SCORE", 0);
                        totalScore =  oldscore;
                        System.out.println("total score......" + totalScore);

                        editor.putInt("OLD_SCORE", totalScore);
                        editor.commit();

                        name = setting.getString("NAME", null);
                        curentscore.setText(Integer.toString(score));
                       // totalscore.setText(Integer.toString(totalScore));

                    }
                }catch (Exception e) {
                }
            }
        }
        FetchData fetchData =new FetchData();
        fetchData.execute();
    }



    //send data on server
    private void sendDataOnServer() {

        class InsertData extends AsyncTask<String,Void,String>{

            ProgressDialog pd=new ProgressDialog(MyScore.this);
            HttpURLConnection conn;
            URL url;
            @Override
            protected void onPreExecute() {

                super.onPreExecute();
                System.out.println("value of name......................."+name);
            }


            @Override
            protected String doInBackground(String... params) {
                String params_deviceid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                String params_name = name.toString().trim().replaceAll("\\s","%20");
                int params_score = totalScore;
                System.out.println("name in background process........"+params_name);


                try {
                    url = new URL("http://bubble.arpitharsola.com/insertscore.php?deviceid=" + params_deviceid + "&name=" +params_name + "&score=" +params_score);

                    conn = (HttpURLConnection) url.openConnection();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    String result = bufferedReader.readLine().toString();
                    return result;
                } catch (Exception e) {
                    e.printStackTrace();
                    return e.toString();
                }

            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                pd.dismiss();
                System.out.println("value of s..."+s);
                String temp=s;
                String temp1="update";
                System.out.println("temp."+temp+temp1);
                if(temp1.trim().equals(temp.trim())){
                }else{
                    Toast.makeText(MyScore.this,"Network problem,Score not updated :)",Toast.LENGTH_SHORT).show();
                }
            }
        }
        InsertData insertData =new InsertData();
        insertData.execute();

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode== KeyEvent.KEYCODE_BACK)
            bclick++;
        if(bclick>1){
          Intent i=new Intent(MyScore.this,GameActivity.class);
          startActivity(i);
        }

        return false;
        // Disable back button..............
    }
}
