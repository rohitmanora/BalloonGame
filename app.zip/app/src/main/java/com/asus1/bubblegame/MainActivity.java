package com.asus1.bubblegame;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.media.Image;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by Asus 1 on 11/5/2017.
 */
public class MainActivity extends AppCompatActivity {

    EditText name,username,mobile;
    ImageView logo;
    Button submit,skip;
    String id;
    int count=0,checkSkip=0;

    public String name1,username1,mobile1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        name=(EditText)findViewById(R.id.fullname);
        logo=(ImageView)findViewById(R.id.imglogo);
        username=(EditText)findViewById(R.id.usernmae);
        mobile=(EditText)findViewById(R.id.mobile);
        submit=(Button)findViewById(R.id.submit);
        skip=(Button)findViewById(R.id.skip);

        SharedPreferences setting = getSharedPreferences("GAME_SCORE", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = setting.edit();
//        final String Did=Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID).toString();


        final String Did = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID).toString();
        fetchRegisterData(Did);
        //getting data nd set in editext
        String setname=setting.getString("NAME",null);
        String setusername=setting.getString("USERNAME",null);
        String setmobile=setting.getString("MOBILE",null);
        System.out.print("name mainActivity................"+setname);
        System.out.print("username..................."+setusername);
        name.setText(setname);
        username.setText(setusername);
        mobile.setText(setmobile);

        int count1 = setting.getInt("COUNT", 0);
        int checkSkip1=setting.getInt("CHECKSKIP",0);
        if(checkSkip1>0){
           // playButton.setVisibility(View.GONE);
            skip.setVisibility(View.GONE);
            logo.setVisibility(View.GONE);
        }
         System.out.print("value of count"+count1);
        if(count1>0){
            Intent i=new Intent(MainActivity.this,GameActivity.class);
            startActivity(i);
        }


        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                count++;
                checkSkip++;
                SharedPreferences setting = getSharedPreferences("GAME_SCORE", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = setting.edit();
                String Name=name1;
                Log.v("name 1 value..",name1);
                Log.v("name  value..",Name);
                editor.putString("NAME",Name);
                editor.putInt("COUNT", count);
                editor.putInt("CHECKSKIP",checkSkip);
                editor.commit();
                String Did=Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID).toString();

                String Username=username1;
                String Mobile=mobile1;
                registerData(Did,Name,Username,Mobile);
                Intent i1=new Intent(MainActivity.this,GameActivity.class);
                startActivity(i1);
                finish();
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String Did=Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID).toString();

                String Name=name.getText().toString().trim().replaceAll("\\s","%20");

                String Username=username.getText().toString().trim().replaceAll("\\s","%20");
                String Mobile=mobile.getText().toString().trim().replaceAll("\\s","%20");
                registerData(Did,Name,Username,Mobile);


                SharedPreferences setting = getSharedPreferences("GAME_SCORE", Context.MODE_PRIVATE);
//                int oldscore = setting.getInt("OLD_SCORE", 0);

                count++;
                SharedPreferences.Editor editor = setting.edit();
                editor.putString("NAME", Name);
                editor.putString("USERNAME",Username);
                editor.putString("MOBILE",Mobile);
                editor.putInt("COUNT", count);
                editor.commit();

                Intent i=new Intent(MainActivity.this,GameActivity.class);
                startActivity(i);
                finish();

            }
        });

    }

    private void fetchRegisterData(String Deviceid) {
        class InsertData extends AsyncTask<String, Void, String> {

            ProgressDialog pd = new ProgressDialog(MainActivity.this);
            HttpURLConnection conn;
            URL url;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd.setMessage("data inserting...");
                pd.setCancelable(false);
                pd.show();
            }


            @Override
            protected String doInBackground(String... params) {
                String params_did = params[0];

                try {
                    url = new URL("http://bubble.arpitharsola.com/fetchuserinfo.php?deviceid=" + params_did);
                    Log.v("fetch url..",String.valueOf(url));
                    conn = (HttpURLConnection) url.openConnection();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    String result = bufferedReader.readLine().toString();
                    return result;
                } catch (Exception e) {
                    e.printStackTrace();
                    return e.toString();
                }

            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                pd.dismiss();
                System.out.println("value of s.........." + s);

                try {
                    JSONObject jsonObject = new JSONObject(s);
                    JSONArray jsonArray = jsonObject.getJSONArray("result");

                    //  for(int i=0;i<jsonArray.length();i++){
                    JSONObject jo = jsonArray.getJSONObject(0);

                    name1 = jo.getString("name");
                    username1 = jo.getString("username");
                    mobile1 = jo.getString("mobile");
                    name.setText(name1);
                    username.setText(username1);
                    System.out.println("username" + username1);
                    mobile.setText(mobile1);
                    // }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }
        InsertData insertData = new InsertData();
        insertData.execute(Deviceid);
    }

    private void registerData(String Deviceid,String Name,String Username1, String Mobile) {

        class InsertData extends AsyncTask<String,Void,String>{

            ProgressDialog pd=new ProgressDialog(MainActivity.this);
            HttpURLConnection conn;
            URL url;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();

                pd.setMessage("data inserting...");
                pd.setCancelable(false);
                pd.show();
            }



@Override
protected String doInBackground(String... params) {
             String params_did=params[0];
               String params_name = params[1];
                String params_username = params[2];
                String params_mobile = params[3];


    try {
        url = new URL("http://bubble.arpitharsola.com/register.php?deviceid=" + params_did + "&name=" + params_name + "&username=" + params_username + "&mobile=" +
                params_mobile);
        Log.v("registr data...",String.valueOf(url));
        //          http://192.168.43.38/Food/updateMenu.php?day=ggd%20&earlymorning=pp%20&breakFast=qq&lunch=ffff&snacks=ff&dinner=lopd

        conn = (HttpURLConnection) url.openConnection();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String result = bufferedReader.readLine().toString();
        return result;
    } catch (Exception e) {
        e.printStackTrace();
        return e.toString();
    }

}

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                pd.dismiss();
                System.out.println("value of s.........."+s);
                if(s.trim().equals("Register")){
                    Toast.makeText(MainActivity.this,"Update... succesfully",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this," not updated",Toast.LENGTH_SHORT).show();
                }
            }
        }
        InsertData insertData =new InsertData();
        insertData.execute(Deviceid,Name,Username1,Mobile);

    }
}
